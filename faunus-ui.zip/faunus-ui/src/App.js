import './App.css';
import Home from './containers/public/home/Home';

function App() {
  return (
    <div>
      <header>
        <Home/>
      </header>
    </div>
  );
}

export default App;
